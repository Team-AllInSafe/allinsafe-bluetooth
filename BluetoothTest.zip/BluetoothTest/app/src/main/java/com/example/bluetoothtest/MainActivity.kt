package com.example.bluetoothtest

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import com.example.bluetoothtest.ui.theme.BluetoothTestTheme

class MainActivity : ComponentActivity() {
    private var bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (BluetoothDevice.ACTION_FOUND == intent.action) {
                val device: BluetoothDevice? = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }

                device?.let {
                    if (ActivityCompat.checkSelfPermission(
                            context,
                            Manifest.permission.BLUETOOTH_CONNECT
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        Log.e("BluetoothScan", "Permission denied for connecting Bluetooth devices.")
                        return
                    }
                    Log.d("BluetoothScan", "Found Device: ${it.name}, MAC: ${it.address}")
                }
            }
        }
    }

    // 블루투스 권한 요청
    private val requestBluetoothPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissionsResult ->
            if (permissionsResult[Manifest.permission.BLUETOOTH_SCAN] == true &&
                permissionsResult[Manifest.permission.BLUETOOTH_CONNECT] == true
            ) {
                Log.d("BluetoothTest", "Bluetooth permissions granted.")
            } else {
                Log.e("BluetoothTest", "Bluetooth permissions denied.")
            }
        }

    private fun requestBluetoothPermissions() {
        val permissions = arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )
        requestBluetoothPermissionsLauncher.launch(permissions)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bluetoothAdapter?.let {
            requestBluetoothPermissions() // 권한 요청
        } ?: Log.e("BluetoothTest", "Device does not support Bluetooth.")

        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        registerReceiver(bluetoothReceiver, filter)

        setContent {
            BluetoothTestTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    BluetoothTestUI(
                        startDiscovery = {
                            bluetoothAdapter?.let { adapter ->
                                val hasScanPermission =
                                    checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                                val hasConnectPermission =
                                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

                                if (hasScanPermission && hasConnectPermission) {
                                    if (adapter.isDiscovering) {
                                        Log.d("BluetoothScan", "Already discovering.")
                                    } else {
                                        adapter.startDiscovery()
                                        Log.d("BluetoothScan", "Discovery started.")
                                    }
                                } else {
                                    Log.e("BluetoothScan", "Permission not granted. " +
                                            "Scan: $hasScanPermission, Connect: $hasConnectPermission")
                                }
                            } ?: Log.e("BluetoothTest", "BluetoothAdapter is null.")
                        },
                                stopDiscovery = {
                            bluetoothAdapter?.let {
                                if (it.isDiscovering) {
                                    it.cancelDiscovery()
                                    Log.d("BluetoothScan", "Discovery stopped.")
                                } else {
                                    Log.d("BluetoothScan", "No active discovery.")
                                }
                            } ?: Log.e("BluetoothTest", "BluetoothAdapter is null.")
                        },
                        checkBluetoothStatus = {
                            bluetoothAdapter?.let {
                                val status = if (it.isEnabled) "Enabled" else "Disabled"
                                Log.d("BluetoothTest", "Bluetooth is $status")
                            } ?: Log.e("BluetoothTest", "BluetoothAdapter is null.")
                        },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(bluetoothReceiver)
    }
}

@Composable
fun BluetoothTestUI(
    startDiscovery: () -> Unit,
    stopDiscovery: () -> Unit,
    checkBluetoothStatus: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "Bluetooth Test")
        Button(onClick = startDiscovery) {
            Text("Start Discovery")
        }
        Button(onClick = stopDiscovery) {
            Text("Stop Discovery")
        }
        Button(onClick = checkBluetoothStatus) {
            Text("Check Bluetooth Status")
        }
    }
}
